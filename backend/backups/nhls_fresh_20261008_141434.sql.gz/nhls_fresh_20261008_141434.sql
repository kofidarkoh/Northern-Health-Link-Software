/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.8-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: nhls_fresh
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `clinic_id` int(11) NOT NULL,
  `specialist_id` int(11) NOT NULL,
  `appointment_time` datetime NOT NULL,
  `status` varchar(20) NOT NULL,
  `video_room_url` text DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `appointment_patient_id` (`patient_id`),
  KEY `appointment_clinic_id` (`clinic_id`),
  KEY `appointment_specialist_id` (`specialist_id`),
  KEY `appointment_created_by_id` (`created_by_id`),
  CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`),
  CONSTRAINT `appointments_ibfk_3` FOREIGN KEY (`specialist_id`) REFERENCES `users` (`id`),
  CONSTRAINT `appointments_ibfk_4` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
INSERT INTO `appointments` VALUES
(1,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,1,1,4,'2026-09-12 11:18:14','COMPLETED','https://meet.nhls.local/1-9165',3),
(2,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,3,2,4,'2026-09-15 09:18:14','SCHEDULED','https://meet.nhls.local/3-9022',2),
(3,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,4,4,5,'2026-09-11 10:18:14','SCHEDULED','https://meet.nhls.local/4-4912',3),
(4,'2026-10-08 13:18:19','2026-10-08 13:18:19',0,8,3,4,'2026-10-06 10:18:14','COMPLETED','https://meet.nhls.local/8-5708',2),
(5,'2026-10-08 13:18:19','2026-10-08 13:18:19',0,9,2,5,'2026-09-17 01:18:14','COMPLETED','https://meet.nhls.local/9-3950',2),
(6,'2026-10-08 13:18:19','2026-10-08 13:18:19',0,10,2,5,'2026-09-30 06:18:14','COMPLETED','https://meet.nhls.local/10-5183',2),
(7,'2026-10-08 13:18:19','2026-10-08 13:18:19',0,11,3,5,'2026-09-20 09:18:14','SCHEDULED','https://meet.nhls.local/11-7951',3),
(8,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,12,1,5,'2026-09-27 04:18:14','COMPLETED','https://meet.nhls.local/12-5847',3),
(9,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,13,4,4,'2026-09-15 06:18:14','COMPLETED','https://meet.nhls.local/13-5689',2),
(10,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,14,3,5,'2026-09-20 08:18:14','REQUESTED','https://meet.nhls.local/14-3153',2),
(11,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,17,1,5,'2026-09-18 08:18:14','CANCELLED',NULL,2),
(12,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,18,2,4,'2026-09-12 06:18:14','COMPLETED','https://meet.nhls.local/18-5951',3),
(13,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,20,1,5,'2026-09-24 06:18:14','SCHEDULED','https://meet.nhls.local/20-4868',3),
(14,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,23,2,4,'2026-09-10 04:18:14','CANCELLED',NULL,2),
(15,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,24,1,5,'2026-10-05 02:18:14','COMPLETED','https://meet.nhls.local/24-2041',3),
(16,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,25,2,4,'2026-09-23 07:18:14','REQUESTED','https://meet.nhls.local/25-7984',2),
(17,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,26,1,5,'2026-09-13 02:18:14','REQUESTED','https://meet.nhls.local/26-2874',2),
(18,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,27,1,4,'2026-09-25 08:18:14','SCHEDULED','https://meet.nhls.local/27-5176',3),
(19,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,28,4,4,'2026-10-06 12:18:14','CANCELLED',NULL,3),
(20,'2026-10-08 13:18:22','2026-10-08 13:18:22',0,29,3,4,'2026-09-27 03:18:14','IN_PROGRESS','https://meet.nhls.local/29-7929',2),
(21,'2026-10-08 13:18:22','2026-10-08 13:18:22',0,30,2,4,'2026-09-17 06:18:14','SCHEDULED','https://meet.nhls.local/30-4674',2),
(22,'2026-10-08 13:18:22','2026-10-08 13:18:22',0,33,1,5,'2026-10-03 09:18:14','REQUESTED','https://meet.nhls.local/33-6062',3),
(23,'2026-10-08 13:18:22','2026-10-08 13:18:22',0,34,3,5,'2026-09-08 04:18:14','CANCELLED',NULL,2),
(24,'2026-10-08 13:18:22','2026-10-08 13:18:22',0,35,3,4,'2026-09-25 12:18:14','SCHEDULED','https://meet.nhls.local/35-5640',3),
(25,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,36,3,4,'2026-09-15 07:18:14','IN_PROGRESS','https://meet.nhls.local/36-3878',2),
(26,'2026-10-08 13:18:23','2026-10-08 13:53:52',0,37,1,5,'2026-10-05 07:18:14','SCHEDULED','https://meet.nhls.local/37-1341',3),
(27,'2026-10-08 13:18:23','2026-10-08 13:54:00',0,38,4,4,'2026-09-22 03:18:14','CANCELLED','https://meet.nhls.local/38-2868',2),
(28,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,40,2,5,'2026-09-18 08:18:14','CANCELLED',NULL,2),
(29,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,41,2,4,'2026-09-24 06:18:14','SCHEDULED','https://meet.nhls.local/41-1616',2),
(30,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,42,2,4,'2026-09-09 01:18:14','IN_PROGRESS','https://meet.nhls.local/42-4084',3),
(31,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,43,3,4,'2026-09-16 06:18:14','SCHEDULED','https://meet.nhls.local/43-8199',2),
(32,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,44,3,4,'2026-09-18 03:18:14','CANCELLED',NULL,3),
(33,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,45,2,4,'2026-09-16 12:18:14','COMPLETED','https://meet.nhls.local/45-6072',3),
(34,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,47,2,5,'2026-09-27 13:18:14','COMPLETED','https://meet.nhls.local/47-6940',3),
(35,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,48,3,4,'2026-09-28 01:18:14','COMPLETED','https://meet.nhls.local/48-3147',3),
(36,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,49,2,5,'2026-09-21 10:18:14','SCHEDULED','https://meet.nhls.local/49-6070',3),
(37,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,50,1,5,'2026-09-18 06:18:14','REQUESTED','https://meet.nhls.local/50-7081',2),
(38,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,52,3,5,'2026-09-27 10:18:14','COMPLETED','https://meet.nhls.local/52-7326',2),
(39,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,53,2,4,'2026-10-04 05:18:14','CANCELLED',NULL,3),
(40,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,54,4,4,'2026-10-04 09:18:14','COMPLETED','https://meet.nhls.local/54-8032',2),
(41,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,55,2,4,'2026-09-11 06:18:14','IN_PROGRESS','https://meet.nhls.local/55-1713',3),
(42,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,56,3,4,'2026-09-20 02:18:14','CANCELLED',NULL,3),
(43,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,57,3,5,'2026-09-23 03:18:14','COMPLETED','https://meet.nhls.local/57-3986',2),
(44,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,58,1,4,'2026-09-13 10:18:14','REQUESTED','https://meet.nhls.local/58-1686',3),
(45,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,59,2,5,'2026-09-13 08:18:14','REQUESTED','https://meet.nhls.local/59-8159',3),
(46,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,60,4,4,'2026-09-16 06:18:14','IN_PROGRESS','https://meet.nhls.local/60-7018',3),
(47,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,61,4,4,'2026-09-29 08:18:14','COMPLETED','https://meet.nhls.local/61-2680',2),
(48,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,63,4,5,'2026-10-04 12:18:14','REQUESTED','https://meet.nhls.local/63-4866',3),
(49,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,65,3,4,'2026-09-14 09:18:14','SCHEDULED','https://meet.nhls.local/65-8311',2),
(50,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,68,1,5,'2026-09-11 11:18:14','SCHEDULED','https://meet.nhls.local/68-3852',3),
(51,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,69,3,5,'2026-09-25 01:18:14','COMPLETED','https://meet.nhls.local/69-7708',2),
(52,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,70,2,5,'2026-09-10 01:18:14','SCHEDULED','https://meet.nhls.local/70-3981',2),
(53,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,71,1,5,'2026-09-18 09:18:14','SCHEDULED','https://meet.nhls.local/71-9740',2),
(54,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,73,3,4,'2026-10-07 03:18:14','REQUESTED','https://meet.nhls.local/73-5336',2),
(55,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,75,4,5,'2026-09-21 12:18:14','COMPLETED','https://meet.nhls.local/75-6228',2),
(56,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,76,3,4,'2026-09-28 04:18:14','CANCELLED',NULL,3),
(57,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,77,2,4,'2026-09-22 06:18:14','IN_PROGRESS','https://meet.nhls.local/77-4944',2),
(58,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,78,2,5,'2026-10-07 07:18:14','SCHEDULED','https://meet.nhls.local/78-1838',2),
(59,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,79,3,4,'2026-10-05 07:18:14','SCHEDULED','https://meet.nhls.local/79-7114',3),
(60,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,80,2,4,'2026-10-07 11:18:14','REQUESTED','https://meet.nhls.local/80-6456',3),
(61,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,81,3,5,'2026-09-15 09:18:14','COMPLETED','https://meet.nhls.local/81-6511',3),
(62,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,83,1,4,'2026-09-18 02:18:14','COMPLETED','https://meet.nhls.local/83-7229',2),
(63,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,84,1,5,'2026-09-23 05:18:14','COMPLETED','https://meet.nhls.local/84-7173',3),
(64,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,86,2,5,'2026-09-08 10:18:14','SCHEDULED','https://meet.nhls.local/86-5571',3),
(65,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,87,1,5,'2026-09-09 01:18:14','COMPLETED','https://meet.nhls.local/87-5480',3),
(66,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,89,3,5,'2026-10-02 05:18:14','SCHEDULED','https://meet.nhls.local/89-5442',3),
(67,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,90,2,4,'2026-10-05 07:18:14','REQUESTED','https://meet.nhls.local/90-6411',3),
(68,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,93,3,5,'2026-09-21 05:18:14','COMPLETED','https://meet.nhls.local/93-9092',2),
(69,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,94,1,5,'2026-09-29 04:18:14','CANCELLED',NULL,2),
(70,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,95,4,4,'2026-09-30 07:18:14','REQUESTED','https://meet.nhls.local/95-4858',3),
(71,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,96,3,4,'2026-09-18 08:18:14','SCHEDULED','https://meet.nhls.local/96-4871',2),
(72,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,99,2,5,'2026-09-17 10:18:14','REQUESTED','https://meet.nhls.local/99-9008',2),
(73,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,100,2,5,'2026-10-08 02:18:14','CANCELLED',NULL,2);
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(120) NOT NULL,
  `entity_type` varchar(80) NOT NULL,
  `entity_id` varchar(50) DEFAULT NULL,
  `details` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `auditlog_user_id` (`user_id`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES
(1,'2026-10-08 12:55:06','2026-10-08 12:55:06',0,1,'LOGIN','users','1','{\"user_id\": \"AD-100001\"}'),
(2,'2026-10-08 12:56:22','2026-10-08 12:56:22',0,1,'LOGIN','users','1','{\"user_id\": \"AD-100001\"}'),
(3,'2026-10-08 12:57:14','2026-10-08 12:57:14',0,1,'LOGIN','users','1','{\"user_id\": \"AD-100001\"}'),
(4,'2026-10-08 13:22:49','2026-10-08 13:22:49',0,1,'PASSWORD_RESET_ADMIN','users','8','{\"user_id\": \"RD-500002\"}'),
(5,'2026-10-08 13:31:29','2026-10-08 13:31:29',0,1,'LOGIN','users','1','{\"user_id\": \"AD-100001\"}'),
(6,'2026-10-08 13:32:29','2026-10-08 13:32:29',0,1,'CLINIC_UPDATED','clinics','1','{\"name\": \"Savelugu Rural Clinic\"}'),
(7,'2026-10-08 13:53:52','2026-10-08 13:53:52',0,1,'APPOINTMENT_STATUS_UPDATED','appointments','26','{\"status\": \"SCHEDULED\"}'),
(8,'2026-10-08 13:54:01','2026-10-08 13:54:01',0,1,'APPOINTMENT_STATUS_UPDATED','appointments','27','{\"status\": \"CANCELLED\"}'),
(9,'2026-10-08 14:01:49','2026-10-08 14:01:49',0,1,'LOGIN','users','1','{\"user_id\": \"AD-100001\"}'),
(10,'2026-10-08 14:07:21','2026-10-08 14:07:21',0,1,'LOGIN','users','1','{\"user_id\": \"AD-100001\"}'),
(11,'2026-10-08 14:07:21','2026-10-08 14:07:21',0,2,'LOGIN','users','2','{\"user_id\": \"CS-200001\"}'),
(12,'2026-10-08 14:07:22','2026-10-08 14:07:22',0,1,'PASSWORD_RESET_ADMIN','users','2','{\"user_id\": \"CS-200001\"}'),
(13,'2026-10-08 14:07:22','2026-10-08 14:07:22',0,2,'LOGIN','users','2','{\"user_id\": \"CS-200001\"}'),
(14,'2026-10-08 14:07:23','2026-10-08 14:07:23',0,2,'PASSWORD_CHANGED','users','2',NULL),
(15,'2026-10-08 14:07:23','2026-10-08 14:07:23',0,2,'LOGIN','users','2','{\"user_id\": \"CS-200001\"}'),
(16,'2026-10-08 14:13:59','2026-10-08 14:13:59',0,1,'LOGIN','users','1','{\"user_id\": \"AD-100001\"}'),
(17,'2026-10-08 14:14:00','2026-10-08 14:14:00',0,2,'LOGIN','users','2','{\"user_id\": \"CS-200001\"}'),
(18,'2026-10-08 14:14:00','2026-10-08 14:14:00',0,1,'USER_UPDATED','users','2','{\"role\": \"CLINIC_STAFF\", \"clinic_id\": null, \"active\": true}'),
(19,'2026-10-08 14:14:00','2026-10-08 14:14:00',0,1,'USER_UPDATED','users','2','{\"role\": \"CLINIC_STAFF\", \"clinic_id\": null, \"active\": true}');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `clinics`
--

DROP TABLE IF EXISTS `clinics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clinics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL,
  `name` varchar(120) NOT NULL,
  `district` varchar(120) NOT NULL,
  `contact_phone` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clinics`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `clinics` WRITE;
/*!40000 ALTER TABLE `clinics` DISABLE KEYS */;
INSERT INTO `clinics` VALUES
(1,'2026-10-08 12:54:33','2026-10-08 13:32:29',0,'Savelugu Rural Clinic','Savelugu District',NULL),
(2,'2026-10-08 12:54:33','2026-10-08 12:54:33',0,'Karaga Health Centre','Karaga District','+233200000002'),
(3,'2026-10-08 12:54:34','2026-10-08 12:54:34',0,'Gushegu Municipal Hospital','Gushegu Municipal','+233200000003'),
(4,'2026-10-08 12:54:34','2026-10-08 12:54:34',0,'Tamale Teaching Hospital','Tamale Metro','+233200000004');
/*!40000 ALTER TABLE `clinics` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `consultation_notes`
--

DROP TABLE IF EXISTS `consultation_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `consultation_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `specialist_id` int(11) NOT NULL,
  `diagnosis` text NOT NULL,
  `recommendations` text DEFAULT NULL,
  `referral_notes` text DEFAULT NULL,
  `treatment_instructions` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `consultationnote_appointment_id` (`appointment_id`),
  KEY `consultationnote_specialist_id` (`specialist_id`),
  CONSTRAINT `consultation_notes_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`),
  CONSTRAINT `consultation_notes_ibfk_2` FOREIGN KEY (`specialist_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consultation_notes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `consultation_notes` WRITE;
/*!40000 ALTER TABLE `consultation_notes` DISABLE KEYS */;
INSERT INTO `consultation_notes` VALUES
(1,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,1,4,'Anemia','Follow up in 2 weeks.',NULL,'As prescribed.'),
(2,'2026-10-08 13:18:19','2026-10-08 13:18:19',0,4,4,'Uncomplicated malaria','Follow up in 2 weeks.',NULL,'As prescribed.'),
(3,'2026-10-08 13:18:19','2026-10-08 13:18:19',0,5,5,'URTI','Follow up in 2 weeks.',NULL,'As prescribed.'),
(4,'2026-10-08 13:18:19','2026-10-08 13:18:19',0,6,5,'Hypertension review','Follow up in 2 weeks.',NULL,'As prescribed.'),
(5,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,8,5,'Uncomplicated malaria','Follow up in 2 weeks.',NULL,'As prescribed.'),
(6,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,9,4,'Anemia','Follow up in 2 weeks.',NULL,'As prescribed.'),
(7,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,12,4,'Uncomplicated malaria','Follow up in 2 weeks.',NULL,'As prescribed.'),
(8,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,15,5,'Hypertension review','Follow up in 2 weeks.',NULL,'As prescribed.'),
(9,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,33,4,'Gastroenteritis','Follow up in 2 weeks.',NULL,'As prescribed.'),
(10,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,34,5,'URTI','Follow up in 2 weeks.',NULL,'As prescribed.'),
(11,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,35,4,'URTI','Follow up in 2 weeks.',NULL,'As prescribed.'),
(12,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,38,5,'Gastroenteritis','Follow up in 2 weeks.',NULL,'As prescribed.'),
(13,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,40,4,'Anemia','Follow up in 2 weeks.',NULL,'As prescribed.'),
(14,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,43,5,'Uncomplicated malaria','Follow up in 2 weeks.',NULL,'As prescribed.'),
(15,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,47,4,'Gastroenteritis','Follow up in 2 weeks.',NULL,'As prescribed.'),
(16,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,51,5,'URTI','Follow up in 2 weeks.',NULL,'As prescribed.'),
(17,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,55,5,'Hypertension review','Follow up in 2 weeks.',NULL,'As prescribed.'),
(18,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,61,5,'Anemia','Follow up in 2 weeks.',NULL,'As prescribed.'),
(19,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,62,4,'URTI','Follow up in 2 weeks.',NULL,'As prescribed.'),
(20,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,63,5,'URTI','Follow up in 2 weeks.',NULL,'As prescribed.'),
(21,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,65,5,'Uncomplicated malaria','Follow up in 2 weeks.',NULL,'As prescribed.'),
(22,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,68,5,'Anemia','Follow up in 2 weeks.',NULL,'As prescribed.');
/*!40000 ALTER TABLE `consultation_notes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `deliveries`
--

DROP TABLE IF EXISTS `deliveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `deliveries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL,
  `prescription_id` int(11) NOT NULL,
  `rider_id` int(11) DEFAULT NULL,
  `requested_by_id` int(11) NOT NULL,
  `delivery_address` text NOT NULL,
  `status` varchar(20) NOT NULL,
  `status_note` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `delivery_prescription_id` (`prescription_id`),
  KEY `delivery_rider_id` (`rider_id`),
  KEY `delivery_requested_by_id` (`requested_by_id`),
  CONSTRAINT `deliveries_ibfk_1` FOREIGN KEY (`prescription_id`) REFERENCES `prescriptions` (`id`),
  CONSTRAINT `deliveries_ibfk_2` FOREIGN KEY (`rider_id`) REFERENCES `users` (`id`),
  CONSTRAINT `deliveries_ibfk_3` FOREIGN KEY (`requested_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deliveries`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `deliveries` WRITE;
/*!40000 ALTER TABLE `deliveries` DISABLE KEYS */;
INSERT INTO `deliveries` VALUES
(1,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,1,8,2,'77 Clinic Junction, Kumbungu District','DELIVERED',NULL),
(2,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,3,8,2,'57 Hospital Rd, Karaga District','DELIVERED',NULL),
(3,'2026-10-08 13:18:19','2026-10-08 13:18:19',0,4,7,3,'87 Clinic Junction, Gushegu Municipal','IN_TRANSIT',NULL),
(4,'2026-10-08 13:18:19','2026-10-08 13:18:19',0,5,8,3,'48 Market St, Tamale Metro','PENDING',NULL),
(5,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,6,7,2,'81 Clinic Junction, Yendi Municipal','PENDING',NULL),
(6,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,7,8,3,'22 Market St, Yendi Municipal','FAILED',NULL),
(7,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,8,7,3,'72 Market St, Savelugu District','PENDING',NULL),
(8,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,10,8,2,'54 Clinic Junction, Kumbungu District','PENDING',NULL),
(9,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,13,7,3,'3 Hospital Rd, Tamale Metro','PICKED_UP',NULL),
(10,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,14,NULL,2,'94 Clinic Junction, Gushegu Municipal','DELIVERED',NULL),
(11,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,15,8,3,'77 Clinic Junction, Tamale Metro','PICKED_UP',NULL),
(12,'2026-10-08 13:18:22','2026-10-08 13:18:22',0,16,8,3,'59 Market St, Savelugu District','PENDING',NULL),
(13,'2026-10-08 13:18:22','2026-10-08 13:18:22',0,17,8,3,'78 Market St, Yendi Municipal','IN_TRANSIT',NULL),
(14,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,18,7,2,'98 Market St, Tolon District','PICKED_UP',NULL),
(15,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,19,7,3,'74 Market St, Tamale Metro','DELIVERED',NULL),
(16,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,20,7,3,'40 Clinic Junction, Kumbungu District','PICKED_UP',NULL),
(17,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,21,7,2,'78 Hospital Rd, Gushegu Municipal','FAILED',NULL),
(18,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,22,NULL,3,'92 Hospital Rd, Yendi Municipal','DELIVERED',NULL),
(19,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,23,7,3,'40 Clinic Junction, Karaga District','DELIVERED',NULL),
(20,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,24,7,3,'13 Clinic Junction, Kumbungu District','FAILED',NULL),
(21,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,26,8,3,'21 Hospital Rd, Savelugu District','FAILED',NULL),
(22,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,27,8,2,'56 Hospital Rd, Kumbungu District','PENDING',NULL),
(23,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,28,8,3,'79 Hospital Rd, Gushegu Municipal','PENDING',NULL),
(24,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,29,7,2,'64 Clinic Junction, Tolon District','DELIVERED',NULL),
(25,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,31,7,3,'46 Hospital Rd, Karaga District','FAILED',NULL),
(26,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,32,8,2,'94 Market St, Tolon District','DELIVERED',NULL),
(27,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,34,7,2,'95 Hospital Rd, Karaga District','IN_TRANSIT',NULL),
(28,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,35,NULL,3,'23 Clinic Junction, Yendi Municipal','IN_TRANSIT',NULL),
(29,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,36,8,2,'79 Hospital Rd, Tolon District','PENDING',NULL),
(30,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,37,NULL,3,'11 Market St, Tolon District','PENDING',NULL),
(31,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,38,8,3,'62 Hospital Rd, Yendi Municipal','FAILED',NULL),
(32,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,39,8,3,'94 Market St, Tamale Metro','IN_TRANSIT',NULL),
(33,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,41,7,3,'18 Market St, Savelugu District','DELIVERED',NULL),
(34,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,44,8,2,'91 Hospital Rd, Karaga District','DELIVERED',NULL),
(35,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,45,7,2,'54 Hospital Rd, Kumbungu District','PENDING',NULL),
(36,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,49,NULL,3,'89 Hospital Rd, Karaga District','DELIVERED',NULL),
(37,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,50,8,2,'98 Hospital Rd, Kumbungu District','DELIVERED',NULL),
(38,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,51,7,2,'74 Clinic Junction, Kumbungu District','PENDING',NULL),
(39,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,52,7,3,'87 Market St, Tamale Metro','DELIVERED',NULL);
/*!40000 ALTER TABLE `deliveries` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lab_requests`
--

DROP TABLE IF EXISTS `lab_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lab_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `requested_by_id` int(11) NOT NULL,
  `test_type` varchar(140) NOT NULL,
  `clinical_reason` text DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `labrequest_patient_id` (`patient_id`),
  KEY `labrequest_requested_by_id` (`requested_by_id`),
  CONSTRAINT `lab_requests_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  CONSTRAINT `lab_requests_ibfk_2` FOREIGN KEY (`requested_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lab_requests`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lab_requests` WRITE;
/*!40000 ALTER TABLE `lab_requests` DISABLE KEYS */;
INSERT INTO `lab_requests` VALUES
(1,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,3,5,'Urinalysis','Fever workup','REQUESTED'),
(2,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,4,5,'Malaria RDT','Fever workup','REQUESTED'),
(3,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,6,3,'Typhoid Test','Fever workup','RESULT_UPLOADED'),
(4,'2026-10-08 13:18:19','2026-10-08 13:18:19',0,8,2,'Full Blood Count','Fever workup','REQUESTED'),
(5,'2026-10-08 13:18:19','2026-10-08 13:18:19',0,9,5,'Sputum TB Test','Fever workup','RESULT_UPLOADED'),
(6,'2026-10-08 13:18:19','2026-10-08 13:18:19',0,11,4,'HIV Screening','Fever workup','REQUESTED'),
(7,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,16,2,'Hemoglobin','Fever workup','REQUESTED'),
(8,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,18,2,'Hepatitis B','Fever workup','REQUESTED'),
(9,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,20,4,'Chest X-ray','Fever workup','RESULT_UPLOADED'),
(10,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,21,3,'Sputum TB Test','Fever workup','REQUESTED'),
(11,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,22,3,'Sputum TB Test','Fever workup','REQUESTED'),
(12,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,23,3,'Blood Glucose','Fever workup','RESULT_UPLOADED'),
(13,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,25,5,'Full Blood Count','Fever workup','REQUESTED'),
(14,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,26,3,'Typhoid Test','Fever workup','REQUESTED'),
(15,'2026-10-08 13:18:22','2026-10-08 13:18:22',0,28,4,'Blood Glucose','Fever workup','RESULT_UPLOADED'),
(16,'2026-10-08 13:18:22','2026-10-08 13:18:22',0,30,4,'Full Blood Count','Fever workup','REQUESTED'),
(17,'2026-10-08 13:18:22','2026-10-08 13:18:22',0,33,3,'Blood Glucose','Fever workup','RESULT_UPLOADED'),
(18,'2026-10-08 13:18:22','2026-10-08 13:18:22',0,35,4,'Malaria RDT','Fever workup','REQUESTED'),
(19,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,36,3,'Chest X-ray','Fever workup','RESULT_UPLOADED'),
(20,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,37,5,'Urinalysis','Fever workup','REQUESTED'),
(21,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,39,5,'Hemoglobin','Fever workup','RESULT_UPLOADED'),
(22,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,40,5,'Hemoglobin','Fever workup','RESULT_UPLOADED'),
(23,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,41,4,'Full Blood Count','Fever workup','RESULT_UPLOADED'),
(24,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,43,4,'Typhoid Test','Fever workup','REQUESTED'),
(25,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,44,2,'Chest X-ray','Fever workup','RESULT_UPLOADED'),
(26,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,48,3,'Hemoglobin','Fever workup','REQUESTED'),
(27,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,52,4,'Full Blood Count','Fever workup','RESULT_UPLOADED'),
(28,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,53,4,'HIV Screening','Fever workup','REQUESTED'),
(29,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,54,5,'Blood Glucose','Fever workup','RESULT_UPLOADED'),
(30,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,56,4,'Chest X-ray','Fever workup','REQUESTED'),
(31,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,62,2,'Full Blood Count','Fever workup','RESULT_UPLOADED'),
(32,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,63,2,'Sputum TB Test','Fever workup','REQUESTED'),
(33,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,64,2,'Sputum TB Test','Fever workup','REQUESTED'),
(34,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,68,2,'HIV Screening','Fever workup','REQUESTED'),
(35,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,70,2,'Full Blood Count','Fever workup','RESULT_UPLOADED'),
(36,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,71,3,'Sputum TB Test','Fever workup','RESULT_UPLOADED'),
(37,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,74,5,'Full Blood Count','Fever workup','RESULT_UPLOADED'),
(38,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,75,5,'HIV Screening','Fever workup','REQUESTED'),
(39,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,76,3,'Hemoglobin','Fever workup','RESULT_UPLOADED'),
(40,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,77,2,'Malaria RDT','Fever workup','REQUESTED'),
(41,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,78,4,'Full Blood Count','Fever workup','REQUESTED'),
(42,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,79,4,'Blood Glucose','Fever workup','REQUESTED'),
(43,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,80,3,'Sputum TB Test','Fever workup','RESULT_UPLOADED'),
(44,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,81,2,'Urinalysis','Fever workup','REQUESTED'),
(45,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,82,2,'Sputum TB Test','Fever workup','REQUESTED'),
(46,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,83,2,'HIV Screening','Fever workup','REQUESTED'),
(47,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,84,4,'Chest X-ray','Fever workup','REQUESTED'),
(48,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,86,4,'Hepatitis B','Fever workup','RESULT_UPLOADED'),
(49,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,87,5,'Typhoid Test','Fever workup','REQUESTED'),
(50,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,88,4,'Full Blood Count','Fever workup','REQUESTED'),
(51,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,89,3,'HIV Screening','Fever workup','REQUESTED'),
(52,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,90,3,'Malaria RDT','Fever workup','RESULT_UPLOADED'),
(53,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,91,3,'Hepatitis B','Fever workup','REQUESTED'),
(54,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,92,5,'Blood Glucose','Fever workup','RESULT_UPLOADED'),
(55,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,93,3,'Full Blood Count','Fever workup','REQUESTED'),
(56,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,94,5,'Typhoid Test','Fever workup','RESULT_UPLOADED'),
(57,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,97,3,'HIV Screening','Fever workup','REQUESTED'),
(58,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,100,2,'Typhoid Test','Fever workup','REQUESTED');
/*!40000 ALTER TABLE `lab_requests` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lab_results`
--

DROP TABLE IF EXISTS `lab_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lab_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL,
  `lab_request_id` int(11) NOT NULL,
  `uploaded_by_id` int(11) NOT NULL,
  `result_summary` text NOT NULL,
  `file_url` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `labresult_lab_request_id` (`lab_request_id`),
  KEY `labresult_uploaded_by_id` (`uploaded_by_id`),
  CONSTRAINT `lab_results_ibfk_1` FOREIGN KEY (`lab_request_id`) REFERENCES `lab_requests` (`id`),
  CONSTRAINT `lab_results_ibfk_2` FOREIGN KEY (`uploaded_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lab_results`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lab_results` WRITE;
/*!40000 ALTER TABLE `lab_results` DISABLE KEYS */;
INSERT INTO `lab_results` VALUES
(1,'2026-10-08 13:18:19','2026-10-08 13:18:19',0,3,6,'Negative',NULL),
(2,'2026-10-08 13:18:19','2026-10-08 13:18:19',0,5,6,'Positive — treat per protocol',NULL),
(3,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,9,6,'Negative',NULL),
(4,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,12,6,'Negative',NULL),
(5,'2026-10-08 13:18:22','2026-10-08 13:18:22',0,15,6,'Within normal limits',NULL),
(6,'2026-10-08 13:18:22','2026-10-08 13:18:22',0,17,6,'Negative',NULL),
(7,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,19,6,'Negative',NULL),
(8,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,21,6,'Within normal limits',NULL),
(9,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,22,6,'Positive — treat per protocol',NULL),
(10,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,23,6,'Within normal limits',NULL),
(11,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,25,6,'Positive — treat per protocol',NULL),
(12,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,27,6,'Negative',NULL),
(13,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,29,6,'Within normal limits',NULL),
(14,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,31,6,'Positive — treat per protocol',NULL),
(15,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,35,6,'Positive — treat per protocol',NULL),
(16,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,36,6,'Negative',NULL),
(17,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,37,6,'Negative',NULL),
(18,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,39,6,'Positive — treat per protocol',NULL),
(19,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,43,6,'Positive — treat per protocol',NULL),
(20,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,48,6,'Within normal limits',NULL),
(21,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,52,6,'Positive — treat per protocol',NULL),
(22,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,54,6,'Negative',NULL),
(23,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,56,6,'Negative',NULL);
/*!40000 ALTER TABLE `lab_results` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `title` varchar(160) NOT NULL,
  `message` text NOT NULL,
  `read_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notification_user_id` (`user_id`),
  KEY `notification_patient_id` (`patient_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
(1,'2026-10-08 13:18:30','2026-10-08 13:19:32',0,1,NULL,'Lab queue backlog','Auto-generated demo alert for admin console testing.','2026-10-08 13:19:32'),
(2,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,1,NULL,'Lab queue backlog','Auto-generated demo alert for admin console testing.','2026-10-08 14:02:01'),
(3,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,1,NULL,'Stock reminder','Auto-generated demo alert for admin console testing.','2026-10-08 14:02:01'),
(4,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,1,NULL,'Lab queue backlog','Auto-generated demo alert for admin console testing.','2026-10-08 14:02:01'),
(5,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,1,NULL,'New appointment spike','Auto-generated demo alert for admin console testing.','2026-10-08 14:02:01'),
(6,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,1,NULL,'Stock reminder','Auto-generated demo alert for admin console testing.','2026-10-08 14:02:01'),
(7,'2026-10-08 13:18:30','2026-10-08 13:19:20',0,1,NULL,'Rider delayed','Auto-generated demo alert for admin console testing.','2026-10-08 13:19:20'),
(8,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,1,NULL,'Rider delayed','Auto-generated demo alert for admin console testing.','2026-10-08 14:02:01'),
(9,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,1,NULL,'Stock reminder','Auto-generated demo alert for admin console testing.','2026-10-08 14:02:01'),
(10,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,1,NULL,'New appointment spike','Auto-generated demo alert for admin console testing.','2026-10-08 14:02:01');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL,
  `clinic_id` int(11) NOT NULL,
  `registered_by_id` int(11) NOT NULL,
  `full_name` varchar(140) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(20) NOT NULL,
  `contact_phone` varchar(30) DEFAULT NULL,
  `district` varchar(120) NOT NULL,
  `medical_history` text DEFAULT NULL,
  `emergency_contact` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_clinic_id` (`clinic_id`),
  KEY `patient_registered_by_id` (`registered_by_id`),
  CONSTRAINT `patients_ibfk_1` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`),
  CONSTRAINT `patients_ibfk_2` FOREIGN KEY (`registered_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES
(1,'2026-10-08 13:18:14','2026-10-08 13:18:14',0,1,2,'Rashida Osei',32,'Female','+233519364231','Kumbungu District',NULL,'+233555412533'),
(2,'2026-10-08 13:18:14','2026-10-08 13:18:14',0,1,3,'Fatima Mensah',12,'Female','+233525613608','Tolon District','None significant','+233511780798'),
(3,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,2,3,'Akosua Fuseini',76,'Female','+233510436124','Yendi Municipal','Hypertension','+233556851341'),
(4,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,4,3,'Efua Bah',28,'Female','+233516859215','Karaga District','Diabetes','+233516490526'),
(5,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,3,3,'Azara Osei',6,'Male','+233545985658','Karaga District','Diabetes','+233515288191'),
(6,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,3,3,'Lariba Traore',9,'Male','+233554376630','Gushegu Municipal','Asthma','+233515354748'),
(7,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,2,2,'Adwoa Osei',59,'Female','+233520915531','Savelugu District','Asthma','+233524059778'),
(8,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,3,2,'Azara Sow',69,'Female','+233520965755','Tamale Metro','Diabetes','+233528115891'),
(9,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,2,3,'Hawa Owusu',30,'Male','+233531169695','Tamale Metro','Asthma','+233514441842'),
(10,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,2,3,'Yaw Alhassan',51,'Male','+233519587950','Savelugu District','Hypertension','+233526550891'),
(11,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,3,3,'Lariba Iddrisu',47,'Female','+233519283286','Tolon District','Diabetes','+233516100827'),
(12,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,1,2,'Abdul Sow',55,'Other','+233514263272','Tamale Metro','Diabetes','+233549989395'),
(13,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,4,3,'Baba Mensah',15,'Other','+233527906335','Yendi Municipal','Asthma','+233517486139'),
(14,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,3,3,'Kwame Fuseini',1,'Female','+233543593765','Yendi Municipal','Hypertension','+233544069940'),
(15,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,1,3,'Mariam Karim',78,'Female','+233520256869','Savelugu District','Hypertension','+233546197113'),
(16,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,1,3,'Memuna Mensah',15,'Female','+233530636923','Gushegu Municipal',NULL,'+233526164618'),
(17,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,1,2,'Rashida Alhassan',9,'Other','+233518439645','Gushegu Municipal','Diabetes','+233546896694'),
(18,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,2,3,'Alhassan Yakubu',28,'Other','+233558984844','Kumbungu District','Hypertension','+233557845195'),
(19,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,3,3,'Issah Mahama',57,'Other','+233540298722','Karaga District','Hypertension','+233525079183'),
(20,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,1,3,'Amina Sule',30,'Other','+233524778538','Karaga District',NULL,'+233557502401'),
(21,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,1,2,'Ibrahim Owusu',43,'Male','+233544504433','Gushegu Municipal','Asthma','+233554894338'),
(22,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,4,2,'Baba Bah',74,'Other','+233541720415','Gushegu Municipal','Diabetes','+233537317331'),
(23,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,2,2,'Salma Yakubu',46,'Male','+233537588606','Tamale Metro',NULL,'+233555188729'),
(24,'2026-10-08 13:18:15','2026-10-08 13:18:15',0,1,2,'Adwoa Abdulai',14,'Female','+233522857392','Gushegu Municipal','None significant','+233540105945'),
(25,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,2,3,'Kwame Osei',60,'Female','+233515058994','Tamale Metro','None significant','+233516570543'),
(26,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,1,2,'Ibrahim Konate',22,'Male','+233542590824','Tamale Metro','Hypertension','+233536913358'),
(27,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,1,2,'Adwoa Mensah',50,'Female','+233540535094','Savelugu District','Diabetes','+233556747464'),
(28,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,4,2,'Yaw Addo',28,'Male','+233548868131','Kumbungu District','None significant','+233514090793'),
(29,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,3,2,'Fatima Alhassan',65,'Other','+233520565131','Karaga District','None significant','+233515376189'),
(30,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,2,2,'Azara Boateng',31,'Male','+233518045454','Tolon District','Hypertension','+233548850600'),
(31,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,1,2,'Yaw Karim',41,'Female','+233523707602','Kumbungu District','Asthma','+233526017943'),
(32,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,3,3,'Abdul Addo',59,'Female','+233514868286','Karaga District','Diabetes','+233551685291'),
(33,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,1,2,'Baba Traore',65,'Female','+233518889009','Savelugu District',NULL,'+233526393649'),
(34,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,3,3,'Kwame Fuseini',70,'Female','+233551048999','Yendi Municipal','None significant','+233510524999'),
(35,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,3,2,'Abdul Osei',15,'Male','+233559822740','Tolon District','Hypertension','+233528276979'),
(36,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,3,2,'Sulemana Abdulai',27,'Female','+233543917427','Tamale Metro','Asthma','+233513409056'),
(37,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,1,3,'Efua Owusu',1,'Female','+233518779158','Kumbungu District','Asthma','+233520843582'),
(38,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,4,3,'Baba Mensah',15,'Male','+233556373541','Gushegu Municipal','None significant','+233512417807'),
(39,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,3,2,'Yaw Bah',6,'Female','+233534471348','Yendi Municipal',NULL,'+233534012171'),
(40,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,2,2,'Issah Diallo',46,'Other','+233537271524','Tolon District','Hypertension','+233525887173'),
(41,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,2,2,'Yaw Mensah',23,'Female','+233537629602','Yendi Municipal','Hypertension','+233527905028'),
(42,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,2,2,'Adwoa Owusu',61,'Female','+233523393105','Yendi Municipal','Diabetes','+233533465179'),
(43,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,3,2,'Akosua Mensah',85,'Female','+233536740599','Savelugu District','Asthma','+233514658747'),
(44,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,3,3,'Mariam Karim',52,'Other','+233532223091','Karaga District',NULL,'+233527529855'),
(45,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,2,3,'Fatima Diallo',77,'Male','+233533198669','Kumbungu District','Asthma','+233539285897'),
(46,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,1,3,'Lariba Traore',33,'Male','+233557565775','Tamale Metro',NULL,'+233544891263'),
(47,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,2,3,'Yaw Boateng',43,'Other','+233531066522','Kumbungu District',NULL,'+233558301890'),
(48,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,3,3,'Issah Yakubu',42,'Male','+233556788864','Savelugu District','None significant','+233518542139'),
(49,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,2,3,'Issah Iddrisu',23,'Other','+233548192007','Savelugu District','Diabetes','+233546771443'),
(50,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,1,3,'Kofi Traore',56,'Other','+233550712368','Kumbungu District','Asthma','+233541204829'),
(51,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,4,3,'Issah Traore',66,'Male','+233559389536','Gushegu Municipal',NULL,'+233529044583'),
(52,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,3,2,'Hawa Konate',40,'Female','+233523363383','Gushegu Municipal',NULL,'+233513101350'),
(53,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,2,3,'Azara Boateng',59,'Male','+233552262839','Tolon District','Hypertension','+233558207378'),
(54,'2026-10-08 13:18:16','2026-10-08 13:18:16',0,4,3,'Adwoa Konate',19,'Male','+233517152952','Yendi Municipal','Diabetes','+233524686180'),
(55,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,2,3,'Fatima Sule',32,'Male','+233540632634','Gushegu Municipal','Diabetes','+233554800383'),
(56,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,3,3,'Azara Karim',55,'Other','+233539924755','Gushegu Municipal','Diabetes','+233540203670'),
(57,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,3,2,'Mariam Osei',67,'Male','+233552060375','Gushegu Municipal','Asthma','+233539519350'),
(58,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,1,3,'Akosua Osei',43,'Female','+233546249002','Karaga District','Hypertension','+233520122074'),
(59,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,2,3,'Sulemana Bah',28,'Male','+233537841313','Tamale Metro','Asthma','+233546414017'),
(60,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,4,3,'Fatima Traore',54,'Male','+233549196905','Kumbungu District',NULL,'+233548633925'),
(61,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,4,3,'Amina Mahama',39,'Male','+233538120042','Tolon District','None significant','+233550483595'),
(62,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,2,3,'Akosua Osei',56,'Male','+233511947822','Tamale Metro','Asthma','+233554887348'),
(63,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,4,2,'Fuseina Bah',80,'Other','+233511809687','Tamale Metro','None significant','+233547875704'),
(64,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,1,2,'Mariam Yakubu',18,'Male','+233522195628','Karaga District','Asthma','+233535441229'),
(65,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,3,2,'Fuseina Abdulai',44,'Male','+233528673485','Yendi Municipal','Diabetes','+233526929655'),
(66,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,1,3,'Amina Sule',7,'Female','+233525047294','Kumbungu District',NULL,'+233553738514'),
(67,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,1,2,'Akosua Traore',3,'Other','+233520226206','Gushegu Municipal','Hypertension','+233541780144'),
(68,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,1,2,'Fuseina Osei',48,'Female','+233550660770','Tolon District',NULL,'+233520990137'),
(69,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,3,2,'Lariba Mensah',40,'Other','+233555456006','Tamale Metro','Diabetes','+233557983824'),
(70,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,2,2,'Lariba Konate',14,'Female','+233555919846','Tolon District',NULL,'+233547979090'),
(71,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,1,3,'Baba Yakubu',85,'Female','+233514627608','Tolon District','Asthma','+233510849071'),
(72,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,4,3,'Salma Yakubu',47,'Male','+233557466679','Gushegu Municipal','Diabetes','+233521820351'),
(73,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,3,3,'Fuseina Yakubu',76,'Female','+233531629494','Yendi Municipal','Hypertension','+233515815848'),
(74,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,3,3,'Akosua Fuseini',73,'Other','+233554841369','Tamale Metro','Asthma','+233511926024'),
(75,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,4,3,'Kwame Alhassan',28,'Female','+233527337736','Savelugu District','Asthma','+233550007285'),
(76,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,3,2,'Alhassan Traore',11,'Female','+233558323392','Tamale Metro','Diabetes','+233547257244'),
(77,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,2,3,'Mariam Alhassan',58,'Male','+233516244704','Savelugu District','Hypertension','+233537138900'),
(78,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,2,3,'Issah Mahama',61,'Other','+233545629567','Savelugu District','Diabetes','+233546935945'),
(79,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,3,3,'Sulemana Fuseini',35,'Female','+233526871415','Gushegu Municipal',NULL,'+233558404572'),
(80,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,2,3,'Salma Sule',24,'Female','+233524521327','Kumbungu District','Diabetes','+233528555575'),
(81,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,3,2,'Yaw Addo',30,'Female','+233522042118','Savelugu District',NULL,'+233557514316'),
(82,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,2,3,'Fatima Owusu',71,'Female','+233556802888','Gushegu Municipal','Diabetes','+233516884540'),
(83,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,1,3,'Memuna Alhassan',57,'Female','+233522372436','Karaga District','Asthma','+233542059863'),
(84,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,1,2,'Adwoa Alhassan',10,'Other','+233552241386','Kumbungu District',NULL,'+233520182227'),
(85,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,2,3,'Ibrahim Konate',16,'Other','+233537928965','Tolon District','None significant','+233551501353'),
(86,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,2,3,'Fuseina Fuseini',39,'Other','+233538778283','Savelugu District','None significant','+233551676438'),
(87,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,1,2,'Hawa Traore',81,'Female','+233527760100','Kumbungu District',NULL,'+233520539923'),
(88,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,2,2,'Baba Boateng',21,'Male','+233537415150','Tamale Metro','None significant','+233541535292'),
(89,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,3,2,'Akosua Addo',37,'Male','+233514776792','Kumbungu District','Hypertension','+233527753960'),
(90,'2026-10-08 13:18:17','2026-10-08 13:18:17',0,2,3,'Salma Sule',29,'Female','+233527826293','Yendi Municipal','Hypertension','+233514792233'),
(91,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,1,2,'Kofi Addo',57,'Male','+233541453788','Kumbungu District','Asthma','+233556958332'),
(92,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,4,3,'Alhassan Sule',64,'Male','+233515398361','Tolon District',NULL,'+233538992952'),
(93,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,3,3,'Amina Boateng',30,'Other','+233549401152','Karaga District','Asthma','+233548671280'),
(94,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,1,2,'Memuna Karim',84,'Male','+233528666771','Gushegu Municipal','None significant','+233539251746'),
(95,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,4,2,'Memuna Mahama',53,'Female','+233531545854','Kumbungu District',NULL,'+233520792773'),
(96,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,3,3,'Sulemana Alhassan',37,'Male','+233546916358','Karaga District','Diabetes','+233515909592'),
(97,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,3,3,'Ama Diallo',52,'Other','+233510077246','Kumbungu District','None significant','+233541002707'),
(98,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,4,2,'Yaw Karim',47,'Other','+233543453305','Kumbungu District','Diabetes','+233513463607'),
(99,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,2,3,'Baba Bah',37,'Male','+233556858766','Tamale Metro',NULL,'+233511937395'),
(100,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,2,2,'Kofi Sule',2,'Other','+233537379791','Karaga District','Hypertension','+233517614246');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `prescriptions`
--

DROP TABLE IF EXISTS `prescriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `prescriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `consultation_note_id` int(11) DEFAULT NULL,
  `prescribed_by_id` int(11) NOT NULL,
  `medication_name` varchar(160) NOT NULL,
  `dosage` varchar(120) NOT NULL,
  `frequency` varchar(120) DEFAULT NULL,
  `duration` varchar(120) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prescription_patient_id` (`patient_id`),
  KEY `prescription_consultation_note_id` (`consultation_note_id`),
  KEY `prescription_prescribed_by_id` (`prescribed_by_id`),
  CONSTRAINT `prescriptions_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  CONSTRAINT `prescriptions_ibfk_2` FOREIGN KEY (`consultation_note_id`) REFERENCES `consultation_notes` (`id`),
  CONSTRAINT `prescriptions_ibfk_3` FOREIGN KEY (`prescribed_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prescriptions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `prescriptions` WRITE;
/*!40000 ALTER TABLE `prescriptions` DISABLE KEYS */;
INSERT INTO `prescriptions` VALUES
(1,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,1,NULL,5,'ORS Sachets','1 sachet/L','After stool','3 days','Take with food. Return if worsening.'),
(2,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,2,NULL,5,'ORS Sachets','1 sachet/L','After stool','3 days','Take with food. Return if worsening.'),
(3,'2026-10-08 13:18:18','2026-10-08 13:18:18',0,5,NULL,4,'Ciprofloxacin','500mg','Twice daily','7 days','Take with food. Return if worsening.'),
(4,'2026-10-08 13:18:19','2026-10-08 13:18:19',0,6,NULL,5,'Paracetamol','500mg','Twice daily','5 days','Take with food. Return if worsening.'),
(5,'2026-10-08 13:18:19','2026-10-08 13:18:19',0,8,NULL,4,'Paracetamol','500mg','Twice daily','5 days','Take with food. Return if worsening.'),
(6,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,13,NULL,5,'Amoxicillin','500mg','Three times daily','7 days','Take with food. Return if worsening.'),
(7,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,14,NULL,4,'ORS Sachets','1 sachet/L','After stool','3 days','Take with food. Return if worsening.'),
(8,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,15,NULL,4,'Paracetamol','500mg','Twice daily','5 days','Take with food. Return if worsening.'),
(9,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,17,NULL,5,'Iron + Folic Acid','60mg','Once daily','30 days','Take with food. Return if worsening.'),
(10,'2026-10-08 13:18:20','2026-10-08 13:18:20',0,18,NULL,4,'Amoxicillin','500mg','Three times daily','7 days','Take with food. Return if worsening.'),
(11,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,20,NULL,4,'Amoxicillin','500mg','Three times daily','7 days','Take with food. Return if worsening.'),
(12,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,21,NULL,4,'Paracetamol','500mg','Twice daily','5 days','Take with food. Return if worsening.'),
(13,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,23,NULL,4,'Artemether-Lumefantrine','80/480mg','Twice daily','3 days','Take with food. Return if worsening.'),
(14,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,24,NULL,5,'Artemether-Lumefantrine','80/480mg','Twice daily','3 days','Take with food. Return if worsening.'),
(15,'2026-10-08 13:18:21','2026-10-08 13:18:21',0,25,NULL,4,'Amoxicillin','500mg','Three times daily','7 days','Take with food. Return if worsening.'),
(16,'2026-10-08 13:18:22','2026-10-08 13:18:22',0,33,NULL,4,'Ciprofloxacin','500mg','Twice daily','7 days','Take with food. Return if worsening.'),
(17,'2026-10-08 13:18:22','2026-10-08 13:18:22',0,34,NULL,4,'Iron + Folic Acid','60mg','Once daily','30 days','Take with food. Return if worsening.'),
(18,'2026-10-08 13:18:22','2026-10-08 13:18:22',0,35,NULL,4,'Iron + Folic Acid','60mg','Once daily','30 days','Take with food. Return if worsening.'),
(19,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,36,NULL,4,'Ciprofloxacin','500mg','Twice daily','7 days','Take with food. Return if worsening.'),
(20,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,37,NULL,4,'Artemether-Lumefantrine','80/480mg','Twice daily','3 days','Take with food. Return if worsening.'),
(21,'2026-10-08 13:18:23','2026-10-08 13:18:23',0,38,NULL,4,'Ciprofloxacin','500mg','Twice daily','7 days','Take with food. Return if worsening.'),
(22,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,42,NULL,5,'Artemether-Lumefantrine','80/480mg','Twice daily','3 days','Take with food. Return if worsening.'),
(23,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,44,NULL,4,'Ciprofloxacin','500mg','Twice daily','7 days','Take with food. Return if worsening.'),
(24,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,47,NULL,4,'ORS Sachets','1 sachet/L','After stool','3 days','Take with food. Return if worsening.'),
(25,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,48,NULL,4,'Ciprofloxacin','500mg','Twice daily','7 days','Take with food. Return if worsening.'),
(26,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,49,NULL,5,'Ciprofloxacin','500mg','Twice daily','7 days','Take with food. Return if worsening.'),
(27,'2026-10-08 13:18:24','2026-10-08 13:18:24',0,50,NULL,5,'Artemether-Lumefantrine','80/480mg','Twice daily','3 days','Take with food. Return if worsening.'),
(28,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,52,NULL,5,'Paracetamol','500mg','Twice daily','5 days','Take with food. Return if worsening.'),
(29,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,53,NULL,5,'Amoxicillin','500mg','Three times daily','7 days','Take with food. Return if worsening.'),
(30,'2026-10-08 13:18:25','2026-10-08 13:18:25',0,55,NULL,5,'Artemether-Lumefantrine','80/480mg','Twice daily','3 days','Take with food. Return if worsening.'),
(31,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,58,NULL,5,'Iron + Folic Acid','60mg','Once daily','30 days','Take with food. Return if worsening.'),
(32,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,61,NULL,5,'Iron + Folic Acid','60mg','Once daily','30 days','Take with food. Return if worsening.'),
(33,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,62,NULL,4,'Ciprofloxacin','500mg','Twice daily','7 days','Take with food. Return if worsening.'),
(34,'2026-10-08 13:18:26','2026-10-08 13:18:26',0,64,NULL,5,'ORS Sachets','1 sachet/L','After stool','3 days','Take with food. Return if worsening.'),
(35,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,65,NULL,4,'ORS Sachets','1 sachet/L','After stool','3 days','Take with food. Return if worsening.'),
(36,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,68,NULL,4,'ORS Sachets','1 sachet/L','After stool','3 days','Take with food. Return if worsening.'),
(37,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,70,NULL,4,'Paracetamol','500mg','Twice daily','5 days','Take with food. Return if worsening.'),
(38,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,73,NULL,4,'Ciprofloxacin','500mg','Twice daily','7 days','Take with food. Return if worsening.'),
(39,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,74,NULL,5,'ORS Sachets','1 sachet/L','After stool','3 days','Take with food. Return if worsening.'),
(40,'2026-10-08 13:18:27','2026-10-08 13:18:27',0,75,NULL,5,'Paracetamol','500mg','Twice daily','5 days','Take with food. Return if worsening.'),
(41,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,77,NULL,5,'Ciprofloxacin','500mg','Twice daily','7 days','Take with food. Return if worsening.'),
(42,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,78,NULL,5,'Iron + Folic Acid','60mg','Once daily','30 days','Take with food. Return if worsening.'),
(43,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,82,NULL,4,'Ciprofloxacin','500mg','Twice daily','7 days','Take with food. Return if worsening.'),
(44,'2026-10-08 13:18:28','2026-10-08 13:18:28',0,83,NULL,4,'ORS Sachets','1 sachet/L','After stool','3 days','Take with food. Return if worsening.'),
(45,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,91,NULL,4,'Artemether-Lumefantrine','80/480mg','Twice daily','3 days','Take with food. Return if worsening.'),
(46,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,92,NULL,4,'Iron + Folic Acid','60mg','Once daily','30 days','Take with food. Return if worsening.'),
(47,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,93,NULL,5,'ORS Sachets','1 sachet/L','After stool','3 days','Take with food. Return if worsening.'),
(48,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,94,NULL,4,'Artemether-Lumefantrine','80/480mg','Twice daily','3 days','Take with food. Return if worsening.'),
(49,'2026-10-08 13:18:29','2026-10-08 13:18:29',0,96,NULL,5,'Amoxicillin','500mg','Three times daily','7 days','Take with food. Return if worsening.'),
(50,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,97,NULL,5,'ORS Sachets','1 sachet/L','After stool','3 days','Take with food. Return if worsening.'),
(51,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,98,NULL,5,'ORS Sachets','1 sachet/L','After stool','3 days','Take with food. Return if worsening.'),
(52,'2026-10-08 13:18:30','2026-10-08 13:18:30',0,99,NULL,5,'Artemether-Lumefantrine','80/480mg','Twice daily','3 days','Take with food. Return if worsening.');
/*!40000 ALTER TABLE `prescriptions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL,
  `clinic_id` int(11) DEFAULT NULL,
  `user_id` varchar(9) NOT NULL,
  `full_name` varchar(120) NOT NULL,
  `email` varchar(160) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL,
  `speciality` varchar(120) DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `fcm_token` varchar(255) DEFAULT NULL,
  `security_question` varchar(200) DEFAULT NULL,
  `security_answer` varchar(200) DEFAULT NULL,
  `must_change_password` tinyint(1) NOT NULL DEFAULT 0,
  `profile_picture` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_user_id` (`user_id`),
  UNIQUE KEY `user_email` (`email`),
  KEY `user_clinic_id` (`clinic_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'2026-10-08 12:54:34','2026-10-08 12:54:34',0,NULL,'AD-100001','System Administrator','admin@northernhealthlink.org','+233200000000','$2b$12$oRzJzGZoKwzG1N/6BWUD.utHLKyb4l70QgmN26IEHKRhWy4hpmsI2','ADMIN',NULL,1,NULL,NULL,NULL,0,NULL),
(2,'2026-10-08 12:54:34','2026-10-08 14:14:00',0,NULL,'CS-200001','Nurse Amina','amina@savelugu.org',NULL,'$2b$12$2G93E2yuvgtmCk//yUhrSO.cpoO.Hi7JQeDTglQkcq/c7upAGsnhG','CLINIC_STAFF',NULL,1,NULL,NULL,NULL,0,NULL),
(3,'2026-10-08 12:54:35','2026-10-08 12:54:35',0,2,'CS-200002','Nurse Fatima','fatima@karaga.org','+233200000002','$2b$12$TckOqC6C6jDNHpoQ2Miw0OiKjNi0jNoNr/KXceKaRwUgGJsH3goqC','CLINIC_STAFF',NULL,1,NULL,NULL,NULL,0,NULL),
(4,'2026-10-08 12:54:35','2026-10-08 12:54:35',0,4,'SP-300001','Dr. Ibrahim','ibrahim@tamale.org','+233200000003','$2b$12$4P4lXifIv0zGK9duo.rb2uOjHpJ6VNXcBVJXODlq.QIjwP0I/8tXq','SPECIALIST','General Medicine',1,NULL,NULL,NULL,0,NULL),
(5,'2026-10-08 12:54:36','2026-10-08 12:54:36',0,4,'SP-300002','Dr. Salma','salma@tamale.org','+233200000004','$2b$12$QJPNfMbDGfL2EgJBGZ/YteDCGUbmWeR.J1zkO8IGmM.w8mdembOhO','SPECIALIST','Pediatrics',1,NULL,NULL,NULL,0,NULL),
(6,'2026-10-08 12:54:36','2026-10-08 12:54:36',0,4,'LO-400001','Lab Officer Mohammed','mohammed@tamale.org','+233200000005','$2b$12$ymt14T4SSAynINdJC2lneuDOw2pmCqECtQKx4fPM2QPuQCzlKV58K','LAB_OFFICER',NULL,1,NULL,NULL,NULL,0,NULL),
(7,'2026-10-08 12:54:36','2026-10-08 12:54:36',0,4,'RD-500001','Rider Abdul','abdul@northernhealthlink.org','+233200000006','$2b$12$vS8HoyCJ5WYGdHjurXwhHOPpEGntpYWc6Glq2iuxi39U/6wqVaapi','RIDER',NULL,1,NULL,NULL,NULL,0,NULL),
(8,'2026-10-08 12:54:37','2026-10-08 13:22:48',0,4,'RD-500002','Rider Kwame','kwame@northernhealthlink.org','+233200000007','$2b$12$s8PP9SVyZWiy/VRbRFqYXOWt8FqeTiYzxwTd3dGwr2q3l7Imc.bi.','RIDER',NULL,1,NULL,NULL,NULL,0,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Dumping routines for database 'nhls_fresh'
--
